// Hack pour regler un bug dans MSVC 6 avec la visibilit� des for
#if !defined(for) && defined(_MSC_VER) && (_MSC_VER <= 1200)
#define for if(0);else for
#endif

