/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 26 janvier 2005                                           */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : solution.h                                                */
/* Description : D�finition de la classe CSolution                         */
/***************************************************************************/

#ifndef _SOLUTION_H_
#define _SOLUTION_H_

#include <vector>
#include <ostream>

#include "antenna.h"
#include "switch.h"

using namespace std;

/**
 * Classe encapsulant une solution (partielle ou compl�te)
 *
 * @short Encapsule une solution
 **/

class CSolution
{
public:
	/**
	 * Constructeur par d�faut
	 **/
	CSolution();

	/**
	 * Constructeur
	 *
	 * @param pNbAntennas Le nombre d'antennes
	 *
	 * @param pNbSwitches Le nombre de commutateurs
	 *
	 * @param pAntennaList La liste des antennes
	 *
	 * @param pSwitchList La liste des commutateurs
	 **/
	CSolution(vector<CAntenna> &pAntennaList, vector<CSwitch> &pSwitchList);

	/**
	 * Destructeur
	 **/
	~CSolution();

	/**
	 * Modifie la r�f�rence vers la liste d'antenne
	 *
	 * @param pAntennaList La nouvelle liste
	 **/
	void setAntennaList(vector<CAntenna> &pAntennaList);

	/**
	 * Modifie la r�f�rence vers la liste de commutateurs
	 *
	 * @param pSwitchList La nouvelle liste
	 **/
	void setSwitchList(vector<CSwitch> &pSwitchList);
	/**
	 * Retourne vrai si la solution est valide (respect des contraintes)
	 *
	 * @return Vrai si la solution est valide
	 **/
	bool isValid() const;

	/**
	 * Retourne vrai si elle est partielle
	 *
	 * @return Vrai si la solution est partielle
	 **/
	bool isPartial() const;

	/**
	 * Retourne le co�t de la solution (du plan d'affectation)
	 *
	 * @return Le co�t de la solution
	 **/
	double getCost() const;

	/**
	 * Methode qui retourne vrai si on peut faire l'assignation entre
	 * une antenne et un commutateur
	 *
	 * @param pAntennaId L'antenne � associer
	 *
	 * @param pSwitchId Le commutateur � associer
	 *
	 * @return Vrai si l'association est possible
	 **/
	bool canAssign(ID pAntennaId, ID pSwitchId) const;

	/**
	 * M�thode qui va executer l'assignation
	 *
	 * @param pAntennaId L'antenne � associer
	 *
	 * @param pSwitchId Le commutateur � associer
	 *
	 * @return Vrai si l'association est un succ�s
	 **/
	bool assign(ID pAntennaId, ID pSwitchId);

	/**
	 * M�thode qui va d�faire une assignation
	 *
	 * @param pAntennaId L'antenne � dissocier
	 *
	 * @return Vrai si la dissociation est un succ�s
	**/
	bool unassign(ID pAntennaId);

	/**
	 * Retourne vrai si une antenne est d�j� assign�e
	 *
	 * @param pAntennaId L'identificateur de l'antenne � tester
	 *
	 * @return Vrai si l'antenne est d�j� associ�e
	 **/
	bool isAssigned(ID pAntennaId) const;

	/**
	 * Retourne le ID du commutateur associ� � l'antenne
	 *
	 * @param pAntennaId L'identificateur de l'antenne
	 *
	 * @return L'identificateur du commutateur
	 **/
	ID getAssignment(ID pAntennaId) const;

	/**
	 * Imprime la solution
	 *
	 * @param out Le flux vers lequel imprimer
	 **/
	void print(ostream &out);

	/**
	 * Surcharge de l'op�rateur << pour l'impression
	 *
	 * @param out Le flux vers lequel imprimer
	 *
	 * @param pSolution La solution � imprimer
	 *
	 * @return Le flux (pour les appels en cascade)
	 **/
	friend ostream &operator << (ostream &out, CSolution &pSolution);

private:
	/**
	 * (Priv�e) Calcule de mani�re incr�mentale le co�t de la solution 
	 * (du plan d'affectation)
	 *
	 * @param pAntennaId L'antenne qui est associ�e
	 *
	 * @param pSwitchId Le commutateur � associer
	 *
	 * @return Le co�t de la solution
	 **/
	double updateCost(ID pAntennnaId, ID pSwitchId);

private:
	/**
	 * Le cout de la solution
	 **/
	//double mCost;
	double mCost;

	/**
	 * La liste des antennes
	 **/
	vector<CAntenna> mAntennaList;

	/**
	 * La iste des commutateurs
	 **/
	vector<CSwitch> mSwitchList;

	/**
	 * La liste des assignations. Chaque case du vecteur correspond � une
	 * antenne et contient l'identificateur du commutateur qui lui est
	 * assign� (ou -1 si l'antenne n'est pas assign�e)
	 **/
	vector<ID> mAssignment;
};

#endif // _SOLUTION_H_
