/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 9 f�vrier 2005                                            */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : descente.h                                                */
/* Description : D�finition de la classe CDescente                         */
/***************************************************************************/

#ifndef _DESCENTE_H_
#define _DESCENTE_H_

#include "base.h"
#include "solution.h"

using namespace std;

/**
 * Classe h�riti�re de CBase qui impl�mente l'algorithme descente
 *
 * @short Impl�mente l'algorithme descente
 **/

class CDescente : public CBase
{
public:
	/**
	 * Constructeur
	 *
	 * @param pInitialSolution La solution initiale
	 **/
	CDescente();

	/**
	 * D�marre la descente
	 *
	 * @param pInitialSolution La solution initiale
	 *
	 * @return La solution trouv�e
	 **/
	CSolution start(const CSolution &pInitialSolution);
};

#endif // _DESCENTE_H_
