#ifndef _TYPES_H_
#define _TYPES_H_

typedef unsigned int ID;
typedef unsigned int SIZE;

#endif // _TYPES_H_
