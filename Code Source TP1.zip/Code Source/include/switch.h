/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 26 janvier 2005                                           */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : switch.h                                                  */
/* Description : D�finition de la classe CSwitch                           */
/***************************************************************************/

#ifndef _SWITCH_H_
#define _SWITCH_H_

#include <vector>
#include "types.h"

using namespace std;

/**
 * Classe encapsulant un commutateur
 *
 * @short Encapsule un commutateur
 **/

class CSwitch
{
public:
	/**
	 * Constructeur
	 **/
	CSwitch();

	/**
	 * Destructeur
	 **/
	~CSwitch();

	/**
	 * Retourne l'identificateur du commutateur
	 *
	 * @return L'identificateur du commutateur
	 **/
	ID getId() const;

	/**
	 * Affecte l'identificateur
	 *
	 * @param pId Le nouvel identificateur
	 **/
	void setId(ID pId);

	/**
	 * Retourne la capacit� d'appels du commutateur
	 *
	 * @return La capacit� d'appels
	 **/
	double getCallCapacity() const;

	/**
	 * Affecte la capacit� d'appels
	 *
	 * @param pCallCapacity La nouvelle capacit� d'appels
	 **/
	void setCallCapacity(double pCallCapacity);

	/**
	 * Retourne le co�t d'association � une antenne
	 *
	 * @param pAntennaId L'identificateur de l'antenne � associer
	 *
	 * @return Le co�t d'association
	 **/
	double getAntennaCost(ID pAntennaId) const;

	/**
	 * Affecte les co�ts d'association aux antennes
	 *
	 * @param pAntennaCost Le nouveau vecteur contenant les co�ts 
	 * d'association aux antennes
	 **/
	void setAntennaCost(const vector<double> pAntennaCost);

private:
	/**
	 * L'identificateur du commutateur
	 **/
	int mId;

	/**
	 * La capacit� d'appels
	 **/
	double mCallCapacity;

	/**
	 * Le vecteur contenant les co�ts d'association aux antennes
	 **/
	vector<double> mAntennaCost;
};

#endif // _SWITCH_H_
