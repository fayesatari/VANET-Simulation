/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 26 janvier 2005                                           */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : glouton.h                                                 */
/* Description : D�finition de la classe CGlouton                          */
/***************************************************************************/

#ifndef _GLOUTON_H_
#define _GLOUTON_H_

#include <vector>
#include <string>
#include "base.h"

using namespace std;

/**
 * Classe h�riti�re de CBase qui impl�mente l'algorithme glouton (vorace)
 *
 * @short Impl�mente l'algorithme glouton
 **/

class CGlouton : public CBase
{
public:
	/**
	 * Fonction qui d�marre la recherche glouton
	 *
	 * @param pRandFactor Le facteur de randomisation
	 *
	 * @return La solution trouv�e
	 **/
	CSolution start(double pRandFactor=0.0);

private:
	/**
	 * Fonction prot�g�e pour trouver la prochaine antenne � traiter
	 *
	 * @param pSolution La solution en cours
	 *
	 * @return L'identificateur de l'antenne � traiter
	 **/
	ID getNextAntenna(const CSolution &pSolution) const;
};

#endif // _GLOUTON_H_
