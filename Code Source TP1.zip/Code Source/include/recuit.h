/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 9 f�vrier 2005                                            */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : recuit.h                                                  */
/* Description : D�finition de la classe CRecuit                           */
/***************************************************************************/

#ifndef _RECUIT_H_
#define _RECUIT_H_

#include "base.h"
#include "solution.h"

using namespace std;

/**
 * Classe h�riti�re de CBase qui impl�mente l'algorithme recuit simul�
 *
 * @short Impl�mente l'algorithme recuit
 **/

class CRecuit : public CBase
{
public:
	/**
	 * Constructeur
	 *
	 * @param pInitialSolution La solution initiale
	 **/
	CRecuit();

	/**
	 * D�marre le recuit simul�
	 *
	 * @param pInitialSolution La solution initiale
	 *
	 * @param pInitTemp La temp�rature initiale
	 *
	 * @param pTFactor Le facteur de refroidissement
	 *
	 * @param pTPalier La longueur d'un palier
	 *
	 * @return La solution trouv�e
	 **/
	CSolution start(const CSolution &pInitialSolution, double pInitTemp, 
		double pTFactor, int pTPalier);

private:
	/**
	 * (Priv�e) Retourne vrai si le mouvement est accept�
	 *
	 * @param pDeltaCost La diff�rence de co�t
	 *
	 * @param pTemp La temp�rature
	 *
	 * @return Vrai si le mouvement est accept�
	 **/
	bool CritMetropolis(double pDeltaCost, double pTemp) const;
};

#endif // _RECUIT_H_
