/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : antenna.h                                                  *
 * Description : Definition de la classe CAntenna                           *
 ****************************************************************************/

#ifndef _ANTENNA_H_
#define _ANTENNA_H_

#include <vector>
#include "types.h"

using namespace std;

/**
 * Classe encapsulant une antenne
 *
 * @short Encapsule une antenne
 **/

class CAntenna
{
public:
	/**
	 * Constructeur
	 **/
	CAntenna();

	/**
	 * Destructeur
	 **/
	~CAntenna();

	/**
	 * Retourne l'identificateur de l'antenne
	 *
	 * @return L'identificateur
	 **/
	ID getId() const;

	/**
	 * Affecte l'identificateur de l'antenne
	 *
	 * @param pId Le nouvel identificateur
	 **/
	void setId(ID pId);

	/**
	 * Retourne le volume d'appel de l'antenne
	 *
	 * @return Le volume d'appel
	 **/
	double getCallVolume() const;

	/**
	 * Affecte le volume d'appel de l'antenne
	 *
	 * @param pCallVolume Le nouveau volume d'appel
	 **/
	void setCallVolume(double pCallVolume);

	/**
	 * Retourne le cout de releve entre deux antennes
	 *
	 * @param pAntennaId L'identificateur de la 2eme antenne
	 *
	 * @return Le cout de releve
	 **/
	double getHandoffCost(ID pAntennaId) const;

	/**
	 * Affecte les couts de releve entre deux antennes
	 *
	 * @param pHandoffCost Le vecteur des couts de releve
	 **/
	void setHandoffCost(const vector<double> &pHandoffCost);

	/**
	 * Retourne le score de l'antenne
	 *
	 * @return Le score
	 **/
	double getScore();

	/**
	 * Affecte le score de l'antenne
	 *
	 * @param pScore Le nouveau score
	 **/
	void setScore(double pScore);

	/**
	 * Retourne l'identificateur du commutateur assign� � cette antenne
	 *
	 * @return L'identificateur du commutateur
	 **/
	ID getSwitchId();

	/**
	 * Affecte l'identificateur du commutateur assign� � cette antenne
	 *
	 * @param pSwitch Le nouvel identificateur du commutateur
	 **/
	void setSwitchId(ID pSwitch);

	/**
	 * L'op�rateur <
	 *
	 * @param pAntenna La 2�me antenne � comparer
	 **/
	bool operator < (const CAntenna &pAntenna) const;

	/**
	 * L'op�rateur >
	 *
	 * @param pAntenna La 2�me antenne � comparer
	 **/
	bool operator > (const CAntenna &pAntenna) const;

private:
	/**
	 * L'identificateur
	 **/
	ID mId;

	/**
	 * Le volume d'appel
	 **/
	double mCallVolume;

	/**
	 * Le vecteur des co�ts de rel�ve. Ce vecteur contient un
	 * co�t pour chaque antenne
	 **/
	vector<double> mHandoffCost;

	/**
	 * Le score de l'antenne. Il sert � d�terminer quelle antenne va �tre
	 * trait�e � chaque it�ration
	 **/
	double mScore;

	/**
	 * Le commutateur auquel l'antenne est attach�e
	 **/
	ID mSwitch;
};

#endif // _ANTENNA_H_
