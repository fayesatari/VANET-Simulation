/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 26 janvier 2005                                           */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : base.h                                                    */
/* Description : D�finition de la classe CBase                             */
/***************************************************************************/

#ifndef _BASE_H_
#define _BASE_H_

#include <vector>
#include <string>
#include "antenna.h"
#include "switch.h"
#include "solution.h"

using namespace std;

/**
 * Classe de base pure encapsulant un algorithme. Tout algorithme doit
 * h�riter de cette classe et impl�menter la m�thode virtuelle start()
 *
 * @short Encapsule un algorithme
 **/

class CBase
{
public:
	/**
	 * Constructeur
	 **/
	CBase();

	/**
	 * Destructeur
	 **/
	~CBase();

public:
	/**
	 * (Statique) Lecture des fichiers d'entree
	 *
	 * @param pFilename Le nom du fichier d'entr�e (sans extension)
	 *
	 * @return Vrai si la lecture �tait un succ�s
	 **/
	static bool read(string pFilename);

protected:
	/**
	 * Le facteur de randomisation
	 **/
	double mRandFactor;

protected:
	/**
	 * (Statique) La liste des antennes
	 **/
	static vector<CAntenna> mAntennaList;

	/**
	 * (Statique) La liste des commutateurs
	 **/
	static vector<CSwitch> mSwitchList;

};

#endif // _BASE_H_
