/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : solution.cpp                                               *
 * Description : Implementation de la classe CSolution                      *
 ****************************************************************************/

#include <iostream>    // Pour l'impression
#include "solution.h"

using namespace std;

// Si INC_COST est d�fini, le co�t est calcul� de mani�re incr�mentale (O(n))
// Sinon, il est recalcul� a partir de 0 (O(n^2))
#define INC_COST

CSolution::CSolution()
  : mCost(0.0)
{
	mAntennaList.clear();
	mSwitchList.clear();
}

CSolution::CSolution(vector<CAntenna> &pAntennaList, vector<CSwitch> &pSwitchList)
  : mAntennaList(pAntennaList), mSwitchList(pSwitchList), mCost(0.0)
{
	mAssignment.resize(mAntennaList.size());

	for (ID i=0;i<mAntennaList.size();i++) {
		mAssignment[i] = (ID)-1;
	}
}

CSolution::~CSolution()
{
}

void CSolution::setAntennaList(vector<CAntenna> &pAntennaList)
{
	mAntennaList = pAntennaList;
}

void CSolution::setSwitchList(vector<CSwitch> &pSwitchList)
{
	mSwitchList = pSwitchList;
}

bool CSolution::isValid() const
{
	/* Si un commutateur a une capacit� nulle, on lui a assign� trop
	   d'antennes et donc la solution n'est pas valide */
	for (ID i=0;i<mSwitchList.size();i++) {
		if (mSwitchList[i].getCallCapacity() < 0) {
			return false;
		}
	}

    return true;
}

bool CSolution::isPartial() const
{
	/* Si au moins une antenne n'est pas assign�e, la solution est
	   partielle */
	for (ID i=0;i<mAntennaList.size();i++) {
		if (mAssignment[i] == -1) {
			return true;
		}
	}

	return false;
}

#ifndef INC_COST
double CSolution::getCost() const
{
	double Cost = 0.0;

	// On additionne les co�ts d'association
	for (ID i=0;i<mAntennaList.size();i++) {
		if (mAssignment[i] != -1) {
			Cost += mSwitchList[mAssignment[i]].getAntennaCost(i);
		}
	}

	// On additionne les co�ts de rel�ve
	for (ID i=0;i<mAntennaList.size();i++) {
		for (ID j=0;j<mAntennaList.size();j++) {
			if (mAssignment[i] != -1 && mAssignment[j] != -1 && mAssignment[i] != mAssignment[j]) {
				Cost += mAntennaList[i].getHandoffCost(j);
			}
		}
	}

	return Cost;
}
#else
double CSolution::getCost() const
{
	return mCost;
}
#endif

double CSolution::updateCost(ID pAntennaId, ID pSwitchId)
{
	//1ere partie : Antenne-Commutateur
	// Si l'antenne est d�j� assign�e
	if (mAssignment[pAntennaId] != -1) {
		double Temp = mCost;
		mCost -= mSwitchList[mAssignment[pAntennaId]].getAntennaCost(pAntennaId);
		mCost += mSwitchList[mAssignment[pAntennaId]].getAntennaCost(pAntennaId);

		mCost -= mSwitchList[mAssignment[pAntennaId]].getAntennaCost(pAntennaId);
	}
	// Si on assigne � un commutateur
	if (pSwitchId != -1) {
		mCost += mSwitchList[pSwitchId].getAntennaCost(pAntennaId);
	}


	//2eme partie : Antenne-Antenne (handoff)
	for (ID i=0;i<mAntennaList.size();i++) {
		// Si l'antenne �tait assign�e, il faut retirer la rel�ve
		if (mAssignment[pAntennaId] != -1) {
			if (mAssignment[i] != -1) {
				if (mAssignment[pAntennaId] != mAssignment[i]) {
					mCost -= mAntennaList[pAntennaId].getHandoffCost(i);
					mCost -= mAntennaList[i].getHandoffCost(pAntennaId);
				}
			}
		}
		// Si l'antenne se fait assigner
		if (pSwitchId != -1) {
			if (mAssignment[i] != -1) {
				if (pSwitchId != mAssignment[i]) {
					mCost += mAntennaList[pAntennaId].getHandoffCost(i);
					mCost += mAntennaList[i].getHandoffCost(pAntennaId);
				}
			}
		}
	}

	return mCost;
}

bool CSolution::canAssign(ID pAntennaId, ID pSwitchId) const
{
	return (mSwitchList[pSwitchId].getCallCapacity() >= mAntennaList[pAntennaId].getCallVolume());
}

bool CSolution::assign(ID pAntennaId, ID pSwitchId)
{
	// Peut-on l'assigner ?
	if (!canAssign(pAntennaId, pSwitchId)) {
		return false;
	}

	// On d�sassigne si jamais elle est d�j� assign�e
	unassign(pAntennaId);

#ifdef INC_COST
	updateCost(pAntennaId, pSwitchId);
#endif

	mSwitchList[pSwitchId].setCallCapacity(
		mSwitchList[pSwitchId].getCallCapacity() - mAntennaList[pAntennaId].getCallVolume());

	mAssignment[pAntennaId] = pSwitchId;

	return true;
}

bool CSolution::unassign(ID pAntennaId)
{
	// Est-elle assign�e ?
	if (!isAssigned(pAntennaId)) {
		return false;
	}
	
#ifdef INC_COST
	updateCost(pAntennaId, -1);
#endif

	mSwitchList[mAssignment[pAntennaId]].setCallCapacity(
		mSwitchList[mAssignment[pAntennaId]].getCallCapacity() + mAntennaList[pAntennaId].getCallVolume());
	mAssignment[pAntennaId] = (ID)-1;
	
	return true;
}

bool CSolution::isAssigned(ID pAntennaId) const
{
	return mAssignment[pAntennaId] != -1;
}

ID CSolution::getAssignment(ID pAntennaId) const
{
	return mAssignment[pAntennaId];
}

void CSolution::print(ostream &out)
{
	for (ID i=0;i<mAntennaList.size();i++) {
		out<<"L'antenne "<<i<<" est raccordee au commutateur "<<mAssignment[i]<<endl;
	}

	out<<"Le cout total est : "<<getCost()<<endl;
	out<<"La solution est "<<(isPartial()?"partielle":"complete")<<"."<<endl;

	if (isPartial()) {
		for (ID i=0;i<mAntennaList.size();i++) {
			if (mAssignment[i] == -1) {
				out<<"L'antenne "<<i<<" n'est pas assignee !"<<endl;
			}
		}
	}
	
	cout<<"La solution "<<(isValid()?"est valide.":"n'est pas valide !")<<endl;
}

ostream &operator << (ostream &out, CSolution &pSolution)
{
	pSolution.print(out);

	return out;
}
