/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : switch.cpp                                                 *
 * Description : Implementation de la classe CSwitch                        *
 ****************************************************************************/

#include "switch.h"


CSwitch::CSwitch()
{
}

CSwitch::~CSwitch()
{
}

ID CSwitch::getId() const
{
	return mId;
}

void CSwitch::setId(ID pId)
{
	mId = pId;
}

double CSwitch::getCallCapacity() const
{
	return mCallCapacity;
}


void CSwitch::setCallCapacity(double pCallCapacity)
{
	mCallCapacity = pCallCapacity;
}


double CSwitch::getAntennaCost(ID pAntennaId) const
{
	return mAntennaCost[pAntennaId];
}

void CSwitch::setAntennaCost(const vector<double> pAntennaCost)
{
	mAntennaCost = pAntennaCost;
}
