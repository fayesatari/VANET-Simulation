/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : base.cpp                                                   *
 * Description : Implementation de la classe CBase                          *
 ****************************************************************************/

#include <fstream>
#include <iostream>
#include "base.h"

using namespace std;


vector<CAntenna> CBase::mAntennaList;
vector<CSwitch> CBase::mSwitchList;

CBase::CBase()
{
}

CBase::~CBase()
{
}

bool CBase::read(string pFilename)
{
	string FilenameDon = pFilename + ".don";
	string FilenameCap = pFilename + ".cap";
	ifstream FileDon;
	ifstream FileCap;

	// Ouverture des fichiers
	FileDon.open(FilenameDon.c_str());
	if (FileDon.fail()) {
		cerr<<"Erreur d'ouverture du fichier "<<FilenameDon<<endl;
		return false;
	}

	FileCap.open(FilenameCap.c_str());
	if (FileCap.fail()) {
		cerr<<"Erreur d'ouverture du fichier "<<FilenameCap<<endl;
		return false;
	}

	SIZE mNbAntennas, mNbSwitches;
	FileDon>>mNbAntennas>>mNbSwitches;

	// Allocation des vecteurs
	mAntennaList.resize(mNbAntennas);
	mSwitchList.resize(mNbSwitches);

	// Affectation des Ids
	for (ID i=0;i<mNbAntennas;i++) {
		mAntennaList[i].setId(i);
	}
	for (ID j=0;j<mNbSwitches;j++) {
		mSwitchList[j].setId(j);
	}

	// Lecture des co�ts d'association des antennes aux commutateurs
	vector<vector<double> > AntSwitchCost;
	AntSwitchCost.resize(mNbSwitches);
	for (ID i=0;i<mNbAntennas;i++) {
		for (ID j=0;j<mNbSwitches;j++) {
			float Cost;
			FileDon>>Cost;
			AntSwitchCost[j].push_back(Cost);
		}
	}
	for (ID j=0;j<mNbSwitches;j++) {
		mSwitchList[j].setAntennaCost(AntSwitchCost[j]);
	}

	// Lecture des co�ts de rel�ve
	vector<double> HandoffCost;
	HandoffCost.resize(mNbAntennas);
	for (ID i=0;i<mNbAntennas;i++) {
		for (ID j=0;j<mNbAntennas;j++) {
			float Cost;
			FileDon>>Cost;
			HandoffCost[j] = Cost;
		}
		mAntennaList[i].setHandoffCost(HandoffCost);
	}

	// Lecture des volumes d'appels des antennes
	for (ID i=0;i<mNbAntennas;i++) {
		double Cap;
		FileCap>>Cap;
		mAntennaList[i].setCallVolume(Cap);
	}

	// Lecture des capacit�s mazximales des commutateurs
	for (ID j=0;j<mNbSwitches;j++) {
		double Cap;
		FileCap>>Cap;
		mSwitchList[j].setCallCapacity(Cap);
	}

	return true;
}
