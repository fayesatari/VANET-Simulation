/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : glouton.cpp                                                *
 * Description : Implementation de la classe CGlouton                       *
 ****************************************************************************/

#include <time.h>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>
#include <stdlib.h>
#include "glouton.h"

using namespace std;


CSolution CGlouton::start(double pRandFactor)
{
	mRandFactor = pRandFactor;
	CSolution Solution(mAntennaList, mSwitchList);

	vector<CAntenna> BestAntennas;

	// Boucle s'ex�cutant n fois (n = nombre d'antennes)
	for (ID i=0;i<mAntennaList.size();i++) {
		// On trouve l'antenne � traiter
		ID k = getNextAntenna(Solution);
		BestAntennas.clear();
		// On associe l'antenne avec tous les commutateurs possibles
		// � chaque association, on calcule le co�t de la solution et
		// on m�morie l'association et son co�t
		for (ID j=0;j<mSwitchList.size();j++) {
			double Temp = Solution.getCost();
			if (Solution.assign(k, j)) {
				mAntennaList[k].setScore(Solution.getCost());
				mAntennaList[k].setSwitchId(j);
				BestAntennas.push_back(mAntennaList[k]);
				Solution.unassign(k);
			}
			if (fabs(Temp - Solution.getCost()) > 0.000000000001) {
				cout<<"Probleme !"<<endl;
				cout<<"Temp : "<<Temp<<"   Cost : "<<Solution.getCost()<<"  diff : "
					<<Temp - Solution.getCost()<<endl;
				cout<<"k : "<<k<<"  j : "<<j<<endl<<endl;
			}
		}

		// On ordonne les associations par leur co�ts
		sort(BestAntennas.begin(), BestAntennas.end(), less<CAntenna>());

		// On calcule le nombre de co�ts distincts
		int NbIntervals = 1;
		for (ID i=0;i<BestAntennas.size()-1;i++) {
			if (BestAntennas[i].getScore() != BestAntennas[i+1].getScore()) {
				NbIntervals++;
			}
		}

		// On choisit un co�t au hasard parmi les meilleurs, d�pendemment
		// du facteur de randomisation (effet de randomisation)
		ID IntervalIndex = 
		    (ID)(double(rand())/RAND_MAX * mRandFactor * NbIntervals);

		// On trouve la premi�re et la derni�re association 
		// qui poss�de ce co�t
		double MinIndex=0, MaxIndex = BestAntennas.size();
		for (ID i=0;i<BestAntennas.size()-1;i++) {
			if (IntervalIndex == 0) {
				MinIndex = i;
			}
			if (IntervalIndex <= 0) {
				MaxIndex = i;
				break;
			}
			if (BestAntennas[i].getScore() != BestAntennas[i+1].getScore()) {
				IntervalIndex--;
			}
		}

		// On choisit une association au hasard parmi celle qui ont le co�t
		// choisi (effet stochastique)
		ID Index = 
			(ID)(double(rand())/RAND_MAX*(MaxIndex-MinIndex) + MinIndex);

		Solution.assign(BestAntennas[Index].getId(), BestAntennas[Index].getSwitchId());
	}

	return Solution;
}

ID CGlouton::getNextAntenna(const CSolution &pSolution) const
{
	vector<CAntenna> BestAntennas;

	for (ID i=0;i<mAntennaList.size();i++) {
		if (pSolution.isAssigned(i)) {
			continue;
		}

		// On calcule le score de l'antenne et on le m�morise 
		// l'antenne et son score
		double Average = 0.0;
		double Minimum = -1;
		int NbSwitches = 0;
		for (ID j=0;j<mSwitchList.size();j++) {
			if (!pSolution.isAssigned(i) && pSolution.canAssign(i, j)) {
				Average += mSwitchList[j].getAntennaCost(i);
				if (Minimum == -1 || Minimum > mSwitchList[j].getAntennaCost(i)) {
					Minimum = mSwitchList[j].getAntennaCost(i);
				}
				NbSwitches++;
			}
		}
		mAntennaList[i].setScore(Average / NbSwitches - Minimum);
		BestAntennas.push_back(mAntennaList[i]);
	}

	// On ordonne les antennes par leur score
	sort(BestAntennas.begin(), BestAntennas.end(), greater<CAntenna>());

	// On calcule le nombre de scores distincts
	int NbIntervals = 1;
	for (ID i=0;i<BestAntennas.size()-1;i++) {
		if (BestAntennas[i].getScore() != BestAntennas[i+1].getScore()) {
			NbIntervals++;
		}
	}

	// On choisit un score au hasard parmi les meilleurs, d�pendemment
	// du facteur de randomisation (effet de randomisation)
	ID IntervalIndex = (ID)(double(rand())/RAND_MAX * mRandFactor * NbIntervals);

	// On trouve la premi�re et la derni�re antenne qui poss�de le score choisi
	double MinIndex=0, MaxIndex = BestAntennas.size();
	for (ID i=0;i<BestAntennas.size()-1;i++) {
		if (IntervalIndex == 0) {
			MinIndex = i;
		}
		if (IntervalIndex <= 0) {
			MaxIndex = i;
			break;
		}
		if (BestAntennas[i].getScore() != BestAntennas[i+1].getScore()) {
			IntervalIndex--;
		}
	}

	// On choisit une antenne au hasard parmi toutes les antennes qui poss�de
	// le score choisi (effet stochastique)
	ID Index = (ID)(double(rand())/RAND_MAX*(MaxIndex-MinIndex) + MinIndex);

	return BestAntennas[Index].getId();
}
