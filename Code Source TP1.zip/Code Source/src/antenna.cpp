/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : antenna.cpp                                                *
 * Description : Implementation de la classe CAntenna                       *
 ****************************************************************************/

#include "antenna.h"


CAntenna::CAntenna()
{
}

CAntenna::~CAntenna()
{
}

ID CAntenna::getId() const
{
	return mId;
}

void CAntenna::setId(ID pId)
{
	mId = pId;
}

double CAntenna::getCallVolume() const
{
	return mCallVolume;
}

void CAntenna::setCallVolume(double pCallVolume)
{
	mCallVolume = pCallVolume;
}

double CAntenna::getHandoffCost(ID pAntennaId) const
{
	return mHandoffCost[pAntennaId];
}

void CAntenna::setHandoffCost(const vector<double> &pHandoffCost)
{
	mHandoffCost = pHandoffCost;
}

double CAntenna::getScore()
{
	return mScore;
}

void CAntenna::setScore(double pScore)
{
	mScore = pScore;
}

ID CAntenna::getSwitchId()
{
	return mSwitch;
}

void CAntenna::setSwitchId(ID pSwitch)
{
	mSwitch = pSwitch;
}

bool CAntenna::operator < (const CAntenna &pAntenna) const
{
	return mScore < pAntenna.mScore;
}

bool CAntenna::operator > (const CAntenna &pAntenna) const
{
	return mScore > pAntenna.mScore;
}
