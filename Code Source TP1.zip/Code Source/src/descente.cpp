/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 9 f�vrier 2005                                            */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : descente.cpp                                              */
/* Description : Impl�mentation de la classe CDescente                     */
/***************************************************************************/

#include <iostream>
#include <vector>
#include <utility>
#include "descente.h"

using namespace std;

CDescente::CDescente()
{
}

CSolution CDescente::start(const CSolution &pInitialSolution)
{
	CSolution Solution = pInitialSolution;

	if (Solution.isPartial()) {
		cerr<<"Erreur : Solution initiale partielle. Descente impossible."<<endl;
		return Solution;
	}
	if (!Solution.isValid()) {
		cerr<<"Erreur : Solution initiale non valide. Descente impossible."<<endl;
		return Solution;
	}

	bool Done = false;
	while (!Done) {
		Done = true;
		double BestCost = Solution.getCost();
		vector<pair<ID, ID> > ListAssignments;

		// Pour chaque antenne
		for (ID i=0;i<mAntennaList.size();i++) {
			ID OldSwitchId = Solution.getAssignment(i);

			//Pour chaque commutateur
			for (ID j=0;j<mSwitchList.size();j++) {
				// On ignore le commutateur auquel l'antenne est d�j� associ�e
				if (j == OldSwitchId) {
					continue;
				}
				// Si l'association est r�ussie
				if (Solution.assign(i, j)) {
					// On v�rifie s'il s'agit d'une meilleure solution
					double Cost = Solution.getCost();
					if (Cost < BestCost) {
						ListAssignments.clear();
						ListAssignments.push_back(pair<ID, ID>(i, j));
						BestCost = Cost;
						Done = false;
					} else if (Cost == BestCost) {
						ListAssignments.push_back(pair<ID, ID>(i, j));
					}
					Solution.assign(i, OldSwitchId);
				}
			}
		}

		// S'il existe une ou des meilleures solutions
		if (!Done) {
			if (ListAssignments.size() > 1) {
				// S'il en existe plusieurs, en choisir une au hasard (stochastique)
				int index = rand()%ListAssignments.size();
				Solution.unassign(ListAssignments[index].first);
				Solution.assign(ListAssignments[index].first, ListAssignments[index].second);
			} else {
				Solution.unassign(ListAssignments[0].first);
				Solution.assign(ListAssignments[0].first, ListAssignments[0].second);
			}
		}
	}

	return Solution;
}
