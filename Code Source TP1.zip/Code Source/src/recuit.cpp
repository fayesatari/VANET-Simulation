/***************************************************************************/
/* Cours       : INF6953A                                                  */
/* Date        : 9 f�vrier 2005                                            */
/* Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                */
/* Fichier     : recuit.cpp                                                */
/* Description : Impl�mentation de la classe CRecuit                       */
/***************************************************************************/

#include <iostream>
#include <vector>
#include <utility>
#include <cmath>
#include "recuit.h"

using namespace std;

CRecuit::CRecuit()
{
}

CSolution CRecuit::start(const CSolution &pInitialSolution, double pInitTemp, 
						 double pTFactor, int pTPalier)
{
	double mInitTemp = pInitTemp;
	double mTFactor = pTFactor;
	int mTPalier = pTPalier;
	double AcceptanceThreshold = 0.005;
	unsigned int AcceptanceCounter = 0;
	unsigned int AcceptanceCounterMax = 10;

	unsigned int NbFrozen = 0;
	double Temp = mInitTemp;

	CSolution BestSolution = pInitialSolution;
	CSolution Solution = pInitialSolution;

	if (Solution.isPartial()) {
		cerr<<"Erreur : Solution initiale partielle. Recuit simul� impossible."<<endl;
		return Solution;
	}
	if (!Solution.isValid()) {
		cerr<<"Erreur : Solution initiale non valide. Recuit simul� impossible."<<endl;
		return Solution;
	}

	bool Done = false;

	while (!Done) {
		double BestCost = Solution.getCost();
		double AcceptanceRate = 0.0;
		unsigned int NbMoves = 0;
		
		// La boucle se rep�te d�pendemment du nombre de paliers
		for (unsigned int k=0;k<mTPalier;k++) {
			// TODO : Changer Rand
			// On choisit une antenne et un commutateur al�atoirement
			// Ceci nous donne donc un mouvement al�atoire
			ID i = rand()%mAntennaList.size();
			ID j = rand()%mSwitchList.size();
			ID OldSwitchId = Solution.getAssignment(i);
			// Si le commutateur est diff�rent de celui associ�e � l'antenne,
			// On effectue le mouvement
			if (j != OldSwitchId) {
				if (Solution.assign(i, j)) {
					double DeltaCost = Solution.getCost() - BestCost;
					// On v�rifie le crit�re Metropolis pour savoir si on 
					// accepte le mouvement
					if (CritMetropolis(DeltaCost, Temp)) {
						BestCost = Solution.getCost();
						NbMoves++;
						if (BestCost < BestSolution.getCost()) {
							BestSolution = Solution;
						}
					} else {
						Solution.assign(i, OldSwitchId);
					}
				}
			}
			
			// Niveau d'acceptation
			AcceptanceRate = NbMoves/double(k+1);
		}

		// Si le niveau d'acceptation est inf�rieur au seuil
		// On incr�mente le compteur d'acceptation, sinon on le remet � 0
		if (AcceptanceRate <= AcceptanceThreshold) {
			AcceptanceCounter++;
		} else {
			AcceptanceCounter = 0;
		}

		// Si le compteur d'acceptation d�passe une certaine valeur,
		// on arr�te notre recherche (crit�re d'arr�t)
		if (AcceptanceCounter == AcceptanceCounterMax) {
			Done = true;
		}

		// Nouvelle temp�rature
		Temp *= mTFactor;

	}

	return BestSolution;
}

bool CRecuit::CritMetropolis(double pDeltaCost, double pTemp) const
{
	if (pDeltaCost <= 0) {
		return true;
	}

	double Prob = exp(-pDeltaCost/pTemp);
	return (double(rand())/RAND_MAX) <= Prob;
}
