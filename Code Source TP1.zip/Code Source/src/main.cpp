/****************************************************************************
 * Cours       : INF6953A                                                   *
 * Travail     : Tp1                                                        *
 * Date        : 26 janvier 2005                                            *
 * Auteurs     : Georges Abou-Khalil et Claude-Olivier Pitt                 *
 * Fichier     : antenna.cpp                                                *
 * Description : Fonction principale                                        *
 ****************************************************************************/

#include <time.h>
#include <iostream>
#include "glouton.h"
#include "descente.h"
#include "recuit.h"

using namespace std;

#define DESCENTE
//#define RECUIT

void initArgv(int argc, char *argv[], string &Filename, double &RandFactor, 
			  int &NbIterations, int &NbRelances, double &InitialTemp,
			  double &TFactor, int &TPalier);

int main(int argc, char *argv[])
{
	string Filename = "..\\data\\test24_100_5";
	double RandFactor = 0.0;
	int NbIterations = 3;
	int NbRelances = 5;
	double InitialTemp = 400.0;
	double TFactor = 0.95;
	int TPalier = 300;

//	initArgv(argc, argv, Filename, RandFactor, NbIterations, NbRelances,
//		InitialTemp, TFactor, TPalier);

	// Initialisation de la germe de ransomisation � partir du temps
	srand(time(0)%1000);

	//Lecture du fichier
	if (CBase::read(Filename) == false) {
		cout<<argv[0]<<endl;
		return 1;
	}

	CRecuit Recuit;
	CDescente Descente;
	CGlouton Glouton;
	double BestDescenteCost = -1;
	CSolution BestDescente;
	double BestRecuitCost = -1;
	CSolution BestRecuit;
	clock_t StartTime;
	clock_t EndTime;
	CSolution Solution;
	double Cost;

	for (int j=0;j<NbRelances;j++) {
		double BestGloutonCost = -1;
		CSolution BestGlouton;

		//cout<<"Relance #"<<j+1<<endl;

		cout << "Debut du glouton..." << endl;;
		for (int i = 0; i < NbIterations; i++) {
			CGlouton Glouton;
			StartTime = clock();
			Solution = Glouton.start(RandFactor);
			EndTime = clock();
			cout << "Iteration " << i + 1 << " a terminee en " << double(EndTime - StartTime) / CLOCKS_PER_SEC << " seconde" << endl;
			Cost = Solution.getCost();
			if (BestGloutonCost == -1 || BestGloutonCost > Cost) {
				BestGloutonCost = Cost;
				BestGlouton = Solution;
			}
		}
		cout << "Fin de glouton. Meilleure solution : " << BestGloutonCost << endl;


#ifdef DESCENTE
		cout << "Debut de la descente...";
		StartTime = clock();
		Solution = Descente.start(BestGlouton);
		EndTime = clock();
		cout << "termine en " << double(EndTime - StartTime) / CLOCKS_PER_SEC << " seconde" << endl;
		Cost = Solution.getCost();
		cout << "Cout apres descente : " << Cost << endl;
		if (BestGloutonCost - Cost >= 0) {
			cout << "Le cout a ete ameliore de " << BestGloutonCost - Cost << ", soit de ";
			cout << (BestGloutonCost - Cost) / BestGloutonCost*100.0 << "%" << endl;
		}
		if (BestDescenteCost == -1 || BestDescenteCost > Cost) {
			BestDescenteCost = Cost;
			BestDescente = Solution;
		}
#endif

#ifdef RECUIT
		cout<<"Debut du recuit simule...";
		StartTime = clock();
		Solution = Recuit.start(BestGlouton, InitialTemp, TFactor, TPalier);
		EndTime = clock();		
		cout<<"termine en "<<double(EndTime-StartTime)/CLOCKS_PER_SEC<<" seconde"<<endl;
		Cost = Solution.getCost();
		cout<<"Cout apres recuit : "<<Cost<<endl;
		if (BestGloutonCost-Cost >= 0) {
			cout<<"Le cout a ete ameliore de "<<BestGloutonCost-Cost<<", soit de ";
			cout<<(BestGloutonCost-Cost)/BestGloutonCost*100.0<<"%"<<endl;
		}
		if (BestRecuitCost == -1 || BestRecuitCost > Cost) {
			BestRecuitCost = Cost;
			BestRecuit = Solution;
		}

		cout<<endl;
#endif
	}

#ifdef DESCENTE
	cout<<"Meilleure solution avec la descente : "<<BestDescenteCost<<endl;
#endif
#ifdef RECUIT
	cout<<"Meilleure solution avec le recuit simule : "<<BestRecuitCost<<endl;
#endif

	system("Pause");
	return 0;
}

void initArgv(int argc, char *argv[], string &Filename, double &RandFactor, 
			  int &NbIterations, int &NbRelances, double &InitialTemp,
			  double &TFactor, int &TPalier)
{
	if (argc == 1) {
		cout<<"Nom du fichier (sans extension) : ";
		cin>>Filename;
		cout<<"Facteur de randomisation pour le glouton : ";
		cin>>RandFactor;
		cout<<"Nombre d'iterations pour le glouton : ";
		cin>>NbIterations;
		cout<<"Nombre de relances pour la descente et le recuit simule : ";
		cin>>NbRelances;
		cout<<"Temperature initiale pour le recuit simule : ";
		cin>>InitialTemp;
		cout<<"Facteur de refroidissement pour le recuit simule : ";
		cin>>TFactor;
		cout<<"Taille du palier pour le recuit simule : ";
		cin>>TPalier;
	} else if (argc == 8) {
		Filename = argv[1];
		RandFactor = atof(argv[2]);
		NbIterations = atoi(argv[3]);
		NbRelances = atoi(argv[4]);
		InitialTemp = atof(argv[5]);
		TFactor = atof(argv[6]);
		TPalier = atoi(argv[7]);
	} else {
		cerr<<"Erreur de syntaxe : tp2 <fichier> <facteur rand> <nbiterations>";
		cerr<<"<nbrelacnes> <tempinit> <tempfacteur> <temppalier>"<<endl;
		cerr<<"Vous pouvez �galement lancer le programme sans agument pour le mode int�ractif"<<endl;
		exit(1);
	}

	if (RandFactor < 0.0 || RandFactor > 1.0) {
		cerr<<"Erreur : Facteur invalide ! Il doit etre compris entre 0 et 1 inclusivement"<<endl;
		exit(1);
	}

	if (NbIterations < 1) {
		cerr<<"Erreur : Nombre d'iterations invalide ! Il doit etre > 0."<<endl;
		exit(1);
	}

	if (NbRelances < 1) {
		cerr<<"Erreur : Nombre de relances invalide ! Il doit etre > 0."<<endl;
		exit(1);
	}

	if (InitialTemp < 0.0) {
		cerr<<"Erreur : Temperature invalide ! Il doit etre > 0."<<endl;
		exit(1);
	}

	if (TFactor < 0.0 || TFactor > 1.0) {
		cerr<<"Erreur : Facteur de temperature invalide ! Il doit etre compris entre 0 et 1 inclusivement"<<endl;
		exit(1);
	}

	if (TPalier < 1) {
		cerr<<"Erreur : Taille du palier invalide ! Il doit etre > 0."<<endl;
		exit(1);
	}
}
